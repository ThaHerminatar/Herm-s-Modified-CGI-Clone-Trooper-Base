include('shared.lua')

SWEP.PrintName				= ""				// 'Nice' Weapon name (Shown on HUD)	
SWEP.Slot				= 4				// Slot in the weapon selection menu
SWEP.SlotPos				= 1				// Position in the slot
SWEP.DrawAmmo				= true				// Should draw the default HL2 ammo counter				// Should draw the default crosshair
SWEP.DrawWeaponInfoBox			= true			// Should draw the weapon info box
SWEP.BounceWeaponIcon   			= false				// Should the weapon icon bounce?
SWEP.CSMuzzleFlashes			= false

